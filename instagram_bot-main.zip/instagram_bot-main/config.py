group_token = ''  # Токен от группы в ВК
data_file = 'data_ex.json'
deletion_dir = 'deletion_dir'
log_file = 'log_dir'

max_file_age = 14   # сколько дней хранить логи

MAX_PARSE_POST_COUNT = 1000    # сколько постов проверять за один раз максимум
OFFSET_PARSE = 50

admin_ids = {
    242306128: 0
}  # id админов

data_base = {
    'post_deleted_count': {}
}

shift = 5
# -*- coding: utf8 -*-
import time

import schedule
import vk_api
import datetime
import os
import threading
import requests
import logging
import json
import sys

from database import DB
from utils import CodeWaiter, DeletionLogger, clear_old_files

from random import randint, sample
from string import ascii_letters, digits
from vk_api.longpoll import VkLongPoll, VkEventType
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
from vk_api.exceptions import ApiError

from instagrapi import Client

from instagrapi.mixins.challenge import ChallengeChoice
from instagrapi.exceptions import (
    BadPassword, ReloginAttemptExceeded, ChallengeRequired,
    SelectContactPointRecoveryForm, RecaptchaChallengeForm,
    FeedbackRequired, PleaseWaitFewMinutes, LoginRequired
)

from config import *
from time import sleep

if log_file not in os.listdir():
    os.mkdir(log_file)

if deletion_dir not in os.listdir():
    os.mkdir(deletion_dir)

now_name = str(datetime.datetime.now()).split('.')[0].replace(':', '.')
os.chdir(log_file)
logging.basicConfig(filename=f"{now_name}.log", level=logging.INFO, filemode="w",
                    format="%(asctime)s %(levelname)-8s %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

CodeWaiter = CodeWaiter()

logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))

os.chdir(os.getcwd().replace(f'\{log_file}', ''))

acc_set_db = DB('database.db', 'inst_acc_db', """id INTEGER NOT NULL UNIQUE,
                                                        login text,
                                                        password text,
                                                        critical_likes integer,
                                                        critical_views integer,
                                                        critical_days integer,
                                                        inst_name text,
                                                        deleted_am_time integer,
                                                        deleted_am_lv integer,
                                                        time_start_check integer,
                                                        proxy_login text,
                                                        proxy_pass text,
                                                        proxy text,
                                                        port text,
                                                        sleep_check_post_b integer,
                                                        sleep_check_post_f integer,
                                                        cycle_time text,
                                                        active_check integer,
                                                        PRIMARY KEY(id AUTOINCREMENT)""")
deleted_posts_db = DB('database.db', 'deleted_posts', """id INTEGER NOT NULL UNIQUE,
                                                        what text,
                                                        what_am integer,
                                                        deleted_am integer,
                                                        date text,
                                                        login text,
                                                        lv integer,
                                                        PRIMARY KEY(id AUTOINCREMENT)
                                                        """)
is_communism_db = DB('database.db', 'is_communism_db', """id INTEGER NOT NULL UNIQUE,
                                                        login text,
                                                        password text,
                                                        proxy text,
                                                        port text,
                                                        communism integer,
                                                        PRIMARY KEY(id AUTOINCREMENT)""")

if not is_communism_db.select('*'):
    is_communism_db.add('login, password, proxy, port, communism', '', '', 0, 0, 0)

vk = vk_api.VkApi(token=group_token)
longpoll = VkLongPoll(vk)
vk._auth_token()

alphabet_list = ascii_letters + digits
already_work = []
already_used = []

drivers_options = {}


def run_bot():
    while True:
        try:
            bot()
        except Exception as ex:
            logging.exception(ex)


def bot():
    logging.info('Бот запущен!')
    global id, event, vk, body, base_keyboard

    main_keyboard = keyboard(({'👀Удаление по лайкам/просмотрам👀': VkKeyboardColor.PRIMARY}),
                             ({'➕Добавить аккаунты➕': None, '📜Вывести аккаунты📜': None}),
                             ({'✏Редактировать информацию об аккаунтах✏': None}),
                             ({'➖Удалить аккаунты➖': None, '♿Вывести лог♿': None}),
                             ({'📤Получить статистику📤': None}),
                             ({'📅Удаление по времени📅': VkKeyboardColor.PRIMARY}))
    edit_accs_info_keyboard_1 = keyboard(({'📱Поменять логин📱': None, '📶Поменять пароль📶': None}),
                                         ({'⛽Добавить/поменять прокси⛽': None}),
                                         ({'📨Использовать единный прокси📨': None}),
                                         ({'⬅Назад⬅': VkKeyboardColor.PRIMARY}))
    edit_accs_info_keyboard_2 = keyboard(({'📱Поменять логин📱': None, '📶Поменять пароль📶': None}),
                                         ({'⛽Добавить/поменять прокси⛽': None}),
                                         ({'📨Использовать разные прокси📨': None}),
                                         ({'⬅Назад⬅': VkKeyboardColor.PRIMARY}))
    likes_set_keyboard = keyboard(({'❤Критическое количество лайков❤': VkKeyboardColor.PRIMARY}),
                                  ({'🕵Критическое количество просмотров🕵': None}),
                                  ({'⏳Задержка между постами⏳': None}),
                                  ({'⌚Возраст начала проверки⌚': None}),
                                  ({'⏱Поменять время запуска аккаунтов⏱': None}),
                                  ({'⬅Назад⬅': VkKeyboardColor.PRIMARY}))
    time_set = keyboard(({'⏰Критическое количество дней⏰': VkKeyboardColor.PRIMARY}),
                        ({'⏳Задержка между постами⏳': None}),
                        ({'⏱Поменять время запуска аккаунтов⏱': None}),
                        ({'⬅Назад⬅': VkKeyboardColor.PRIMARY}))
    base_keyboard = main_keyboard

    try:
        for event in longpoll.listen():
            if event.type == VkEventType.MESSAGE_NEW and event.to_me:
                id = event.user_id
                mes = event.text
                if id in admin_ids.keys():
                    if CodeWaiter.has_logins():
                        if len(body) == 6 and body.isdigit():
                            base_mes(f"Код получен, пробую авторизоваться в {CodeWaiter.next_login()}")
                        else:
                            base_mes(f"Неверный код авторизации для {CodeWaiter.next_login()}, попробуйте еще раз!"
                                     f"\nКод должен состоять из 6 цифр")
                    if mes == '⬅Назад⬅':
                        base_keyboard = main_keyboard
                        base_mes('Возвращаемся в главное меню👣')
                        admin_ids[id] = 0
                    elif mes == '👀Удаление по лайкам/просмотрам👀':
                        admin_ids[id] = 0
                        base_keyboard = likes_set_keyboard
                        base_mes('🚪Вы открыли меню для редакции удаления по лайкам/просмотрам')
                    elif mes == '✏Редактировать информацию об аккаунтах✏':
                        admin_ids[id] = 0
                        lpps = acc_set_db.select('login, password, proxy, port, proxy_login, proxy_pass')
                        head = '📝Ниже представлены логины, их пароли и подключенные к ним прокси в формате: логин:пароль:ip прокси:порт прокси:логин прокси:пароль прокси:\n\n'
                        list_accs = ''
                        communism = is_communism_db.select('*')[0]
                        if communism[5]:
                            head += f'🛑 На аккаунтах активен единый прокси. Данные единого прокси в формате: ip прокси:порт прокси:логин прокси:пароль прокси:\n\n{communism[3]}:{communism[4]}:{communism[1]}:{communism[2]}\n\n'

                        for lpp in lpps:
                            list_accs += f'{lpp[0]}:{decoder(lpp[1])}:{lpp[2]}:{lpp[3]}:{lpp[4]}:{lpp[5]}\n' if lpp[
                                                                                                                    2] and \
                                                                                                                lpp[
                                                                                                                    3] and \
                                                                                                                lpp[
                                                                                                                    4] and \
                                                                                                                lpp[
                                                                                                                    5] else f'{lpp[0]}:{decoder(lpp[1])}:прокси отсутствует\n'
                        text = head + list_accs if list_accs else 'К сожалению, Вами не было залито еще ни одного аккаунта'
                        message(id, text, base_keyboard)
                        if int(is_communism_db.select('communism')[0][0]):
                            base_keyboard = edit_accs_info_keyboard_2
                        else:
                            base_keyboard = edit_accs_info_keyboard_1
                        base_mes('🚪Вы открыли меню для редакции информации об аккаунтах')
                    elif mes == '📅Удаление по времени📅':
                        admin_ids[id] = 0

                        base_keyboard = time_set
                        base_mes('🚪Вы открыли меню для редакции удаления по времени')
                    elif mes == '📜Вывести аккаунты📜':
                        admin_ids[id] = 0

                        print_full_list_accs()
                    elif mes == '📤Получить статистику📤':
                        admin_ids[id] = 0

                        statistics_data = get_deletion_statistic()
                        accounts = acc_set_db.select(f'login')

                        for i in accounts:
                            login = i[0]
                            if login not in statistics_data:
                                statistics_data[login] = 0

                        statistics = '\n'.join([f'&#128312; {key}: {value}' for key, value in statistics_data.items()])

                        send_message(id,
                                     f'Удалено постов за сегодня:\n\n{statistics}\n\nВ папке {deletion_dir} на сервере вы можете посмотреть подробные логи удаления')
                    elif mes == '❤Критическое количество лайков❤':
                        list_critical_likes = create_list_accs('critical_likes', 'критическое количество лайков')
                        if list_critical_likes:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новое минимальное количество лайков:\n\nлогин1:кол-во лайков 1\nлогин2:кол-во лайков 2')
                            admin_ids[id] = 2
                    elif admin_ids[id] == 2:
                        for personal_data in mes.split('\n'):
                            try:
                                cr_likes = personal_data.split(':')
                                acc_set_db.update_with_label('critical_likes', 'login', int(cr_likes[1].strip()),
                                                             cr_likes[0].strip())
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except ValueError:
                                base_mes(
                                    f'🆘Ошибка в строке {personal_data}. Критическое количество лайков вводится ЧИСЛОМ!')
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Критическое количество лайков успешно отредактировано!')
                        admin_ids[id] = 0
                    elif mes == '🕵Критическое количество просмотров🕵':
                        list_critical_views = create_list_accs('critical_views', 'критическое количество просмотров')
                        if list_critical_views:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новое минимальное количество просмотров:\n\nлогин1:кол-во просмотров 1\nлогин2:кол-во просмотров 2')
                            admin_ids[id] = 3
                    elif admin_ids[id] == 3:
                        for personal_data in mes.split('\n'):
                            try:
                                critical_views = personal_data.split(':')
                                acc_set_db.update_with_label('critical_views', 'login', int(critical_views[1].strip()),
                                                             critical_views[0].strip())
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except ValueError:
                                base_mes(
                                    f'🆘Ошибка в строке {personal_data}. Критическое количество просмотров вводится ЧИСЛОМ!')
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Критическое количество просмотров успешно отредактировано!')
                        admin_ids[id] = 0
                    elif mes == '⏰Критическое количество дней⏰':
                        list_final_days = create_list_accs('critical_days', 'критическое количество дней')
                        if list_final_days:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новый максимальный возраст постов в днях:\n\nлогин1:кол-во дней 1\nлогин2:кол-во дней 2')
                            admin_ids[id] = 4
                    elif admin_ids[id] == 4:
                        for personal_data in mes.split('\n'):
                            try:
                                critical_days = personal_data.split(':')
                                acc_set_db.update_with_label('critical_days', 'login', int(critical_days[1].strip()),
                                                             critical_days[0])
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except ValueError:
                                base_mes(
                                    f'🆘Ошибка в строке {personal_data}. Критическое количество дней вводится ЧИСЛОМ!')
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Критическое количество дней успешно отредактировано!')
                        admin_ids[id] = 0
                    elif mes == '➕Добавить аккаунты➕':
                        base_mes(
                            """➕ Напишите в столбик данные об аккаунтах. Данные должны содержать значения, разделенные двоеточием (":")\n\n⚡ Значения:\n- логин (строка)\n- пароль (строка)\n- критическое кол-во лайков (целое число)\n- критическое кол-во просмотров (целое число)\n- критическое кол-во дней (целое число)\n- имя в Instagram (строка)\n- сколько дней должно быть посту для проверки. Нижний порог, так сказать (целое число)\n- время ежедневной проверки (чч.мм, пример 01.20 - час двадцать ночи)\n- активность проверки (0 - неактивна, 1 - активна)\n\nПример:\nлогин:пароль:1:1:1:логин:1:01.20:1\nлогин:пароль:1:1:1:логин:1:01.20:1\nлогин:пароль:1:1:1:логин:1:01.20:1""")
                        admin_ids[id] = 1
                    elif admin_ids[id] == 1:
                        for personal_data in mes.split('\n'):
                            try:
                                login_and_pass = personal_data.split(':')
                                password = coder(login_and_pass[1])
                                acc_set_db.add(
                                    'login, password, critical_likes, critical_views, critical_days, inst_name, time_start_check, deleted_am_time, deleted_am_lv, sleep_check_post_b, sleep_check_post_f, cycle_time, active_check',
                                    login_and_pass[0], password, int(login_and_pass[2]), int(login_and_pass[3]),
                                    int(login_and_pass[4]),
                                    login_and_pass[5], int(login_and_pass[6]), 0, 0, randint(20, 40), randint(41, 60),
                                    login_and_pass[7], int(login_and_pass[8]))
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано недостаточно значений. Проверьте, чтобы у Вас через двоеточие были указаны все значения!')
                                continue
                            except ValueError:
                                base_mes(
                                    f'🆘В строке {personal_data} указаны некорректные значения.')
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Аккаунты успешно добавлены!')
                        admin_ids[id] = 0
                    elif mes == '⏳Задержка между постами⏳':
                        sleeps_data = acc_set_db.select(f'login, sleep_check_post_b, sleep_check_post_f')
                        list_sleeps = ''
                        for sleep in sleeps_data:
                            list_sleeps += f'{sleep[0]}:{sleep[1]}-{sleep[2]}\n'
                        if list_sleeps:
                            message(
                                id,
                                f'📝Ниже представлен список нынешних значений в формате:\nлогин:минимальное время-максимальное время(в секундах)\n\n{list_sleeps}',
                                base_keyboard)
                            base_mes(
                                '✒Напишите новый промежуток в формате: аккаунт:минимальное значение-максимальное значение')
                            admin_ids[id] = 6
                        else:
                            base_mes('К сожалению, Вы не добавили ни одного аккаунта, поэтому редакция невозможна')
                    elif admin_ids[id] == 6:
                        for personal_data in mes.split('\n'):
                            try:
                                sleep_check_post = personal_data.split(':')
                                sleep_check_post[1] = sleep_check_post[1].split('-')
                                acc_set_db.update_with_label('sleep_check_post_b', 'login',
                                                             int(sleep_check_post[1][0]), sleep_check_post[0])
                                acc_set_db.update_with_label('sleep_check_post_f', 'login',
                                                             int(sleep_check_post[1][1]), sleep_check_post[0])
                            except ValueError:
                                base_mes(f'🆘Ошибка в строке {personal_data}. Промежуток вводится ЧИСЛОМ!')
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано недостаточно значений. Проверьте, чтобы у Вас через двоеточие были указаны все значения!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Задержка между постами успешно отредактирована')
                        admin_ids[id] = 0
                    elif mes == '⌚Возраст начала проверки⌚':
                        list_start = create_list_accs('time_start_check', 'возраст начала проверки')
                        if list_start:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новый возраст начала проверки постов в днях:\n\nлогин1:кол-во дней 1\nлогин2:кол-во дней 2')
                            admin_ids[id] = 7
                    elif admin_ids[id] == 7:
                        for personal_data in mes.split('\n'):
                            try:
                                time_start_check = personal_data.split(':')
                                acc_set_db.update_with_label('time_start_check', 'login',
                                                             int(time_start_check[1].strip()), time_start_check[0])
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except ValueError:
                                base_mes(f'🆘Ошибка в строке {personal_data}. Возраст начала проверки вводится ЧИСЛОМ!')
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Возраст начала проверки постов успешно отредактирован!')
                        admin_ids[id] = 0
                    elif mes == '📱Поменять логин📱':
                        logins_list = create_list_accs('login', 'текущие логины', 'inst_name')
                        if logins_list:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новый логин:\n\nимя в Instagram 1:логин 1\nимя в Instagram 2:логин 2')
                            admin_ids[id] = 8
                    elif admin_ids[id] == 8:
                        for personal_data in mes.split('\n'):
                            try:
                                new_logins = personal_data.split(':')
                                acc_set_db.update_with_label('login', 'inst_name', new_logins[1],
                                                             new_logins[0])
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Логины успешно отредактированы!')
                        admin_ids[id] = 0
                    elif mes == '📶Поменять пароль📶':
                        pass_col = acc_set_db.select(f'login, password')
                        pass_list = ''
                        for passw in pass_col:
                            pass_list += f'{passw[0]}:{decoder(passw[1])}\n'
                        if pass_list:
                            message(
                                id,
                                f'📝Ниже представлен список нынешних значений в формате:\nлогин:пароль\n\n{pass_list}',
                                base_keyboard)
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новый пароль:\n\nлогин1:пароль 1\nлогин2:пароль 2')
                            admin_ids[id] = 9
                        else:
                            base_mes('К сожалению, Вы не добавили ни одного аккаунта, поэтому редакция невозможна')
                    elif admin_ids[id] == 9:
                        for personal_data in mes.split('\n'):
                            try:
                                new_passwords = personal_data.split(':')
                                password = coder(new_passwords[1])
                                acc_set_db.update_with_label('password', 'login', password,
                                                             new_passwords[0])
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Пароли успешно отредактированы!')
                        admin_ids[id] = 0
                    elif mes == '⛽Добавить/поменять прокси⛽':
                        proxies_col = acc_set_db.select(f'login, proxy, port, proxy_login, proxy_pass')
                        proxies_list = ''
                        for proxy in proxies_col:
                            proxies_list += (f'{proxy[0]}:{proxy[1]}:{proxy[2]}:{proxy[3]}:{proxy[4]}\n' if proxy[1] and \
                                                                                                            proxy[2] and \
                                                                                                            proxy[3] and \
                                                                                                            proxy[
                                                                                                                4] else f'{proxy[0]}:прокси отсутствует') + '\n'
                        if proxies_list:
                            message(
                                id,
                                f'📝Вот список уже имеющихся прокси в формате:\nлогин от inst:ip адресс:порт:логин от прокси:пароль от прокси\n\n{proxies_list}',
                                base_keyboard)
                        base_mes(
                            '🤓Укажите в столбик логин от инстаграмма, а через двоекточие IP адресс прокси, порт прокси, логин проксиб пароль прокси:\n\nлогин_inst1:прокси1:порт1:логин_прокси1:пароль_прокси1\nлогин_inst2:прокси2:порт2:логин_прокси2:пароль_прокси2\n+79863418920:163.172.91.58:22256:u3os5g:oUJGP6')
                        admin_ids[id] = 10
                    elif admin_ids[id] == 10:
                        for personal_data in mes.split('\n'):
                            try:
                                new_proxy = personal_data.split(':')
                                acc_set_db.update_with_label('proxy_login', 'login', new_proxy[3],
                                                             new_proxy[0])
                                acc_set_db.update_with_label('proxy_pass', 'login', new_proxy[4],
                                                             new_proxy[0])
                                acc_set_db.update_with_label('proxy', 'login', new_proxy[1],
                                                             new_proxy[0])
                                acc_set_db.update_with_label('port', 'login', new_proxy[2],
                                                             new_proxy[0])
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {personal_data} указано недостаточно значений. Проверьте, чтобы у Вас были перечислены все значения через двоеточие!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Прокси успешно отредактированы!')
                        admin_ids[id] = 0
                    elif mes == '📨Использовать единный прокси📨':
                        admin_ids[id] = 11
                        base_mes(
                            '🤓Укажите в столбик IP адресс прокси, а через двоеточие порт прокси, логин прокси, пароль прокси:\n\nпрокси:порт:логин_прокси:пароль_прокси')
                    elif admin_ids[id] == 11:
                        try:
                            proxies_data = mes.split(':')
                            is_communism_db.update_with_label('proxy', 'id', proxies_data[0], 1)
                            is_communism_db.update_with_label('port', 'id', proxies_data[1], 1)
                            is_communism_db.update_with_label('login', 'id', proxies_data[2], 1)
                            is_communism_db.update_with_label('password', 'id', proxies_data[3], 1)
                            is_communism_db.update_with_label('communism', 'id', 1, 1)
                            base_keyboard = edit_accs_info_keyboard_2
                            base_mes('Указанный прокси введен в использование всеми аккаунтами')
                        except IndexError:
                            base_mes('Указано недостаточное количество значений!')
                        except Exception as ex:
                            logging.exception(ex)
                        admin_ids[id] = 0
                    elif mes == '📨Использовать разные прокси📨':
                        base_keyboard = edit_accs_info_keyboard_1
                        is_communism_db.update_with_label('communism', 'id', 0, 1)
                        base_mes('Использование разных прокси успешно включено!')
                    elif mes == '🏁Поменять статус проверок🏁':
                        status_col = create_list_accs('active_check', 'активность(0-неактивен, 1-активен)')
                        if status_col:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие статус аккаунта(0-неактивен, 1-активен):\n\nлогин1:статус1\nлогин2:статус2')
                            admin_ids[id] = 12
                    elif admin_ids[id] == 12:
                        for status in mes.split('\n'):
                            try:
                                new_status = status.split(':')
                                acc_set_db.update_with_label('active_check', 'login', int(new_status[1]), new_status[0])
                            except ValueError:
                                base_mes(
                                    f'⚠В строке {status} ошибка! Требуется указывать значения 0 или 1, чтобы обозначить статус проверки.')
                                continue
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {status} указано <2 значений. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Статус проверок успешно отредактирован!')
                        admin_ids[id] = 0
                    elif mes == '➖Удалить аккаунты➖':
                        print_full_list_accs()
                        base_mes(
                            '🤓Укажите в столбик логины от инстаграмма, который требуется удалить')
                        admin_ids[id] = 13
                    elif admin_ids[id] == 13:
                        for login in mes.split('\n'):
                            try:
                                acc_set_db.deleter('login', login)
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Аккаунты успешно удалены!')
                        admin_ids[id] = 0
                    elif mes == '♿Вывести лог♿':
                        try:
                            os.chdir(log_file)
                            log_col = os.listdir()
                            x = 1
                            doc_col = ''
                            for log in log_col:
                                try:
                                    if x < 10:
                                        result = json.loads(
                                            requests.post(
                                                vk.method("docs.getMessagesUploadServer",
                                                          {'type': 'doc', 'peer_id': id})[
                                                    'upload_url'],
                                                files={'file': open(log, 'rb')}).text)
                                        jsonAnswer = vk.method('docs.save',
                                                               {'file': result['file'], 'title': log, 'tags': []})
                                        doc_col += f'doc{jsonAnswer["doc"]["owner_id"]}_{jsonAnswer["doc"]["id"]},'
                                        if x == 10:
                                            message(id, a=doc_col)
                                            x = 0
                                            doc_col = ''
                                        else:
                                            x += 1
                                except KeyError:
                                    pass
                                except Exception as ex:
                                    logging.exception(ex)
                                finally:
                                    try:
                                        if now_name not in log:
                                            os.remove(f'{os.getcwd()}\\{log}')
                                    except Exception as ex:
                                        logging.exception(ex)
                            try:
                                message(id, a=doc_col)
                            except ApiError:
                                pass
                        except KeyError:
                            base_mes('К счастью, в логе еще ничего нет!')
                        except Exception as ex:
                            logging.exception(ex)
                        os.chdir(os.getcwd().replace(f'\{log_file}', ''))
                    elif mes == '⏱Поменять время запуска аккаунтов⏱':
                        time_list = create_list_accs('cycle_time', 'время ежедневной проверки')
                        if time_list:
                            base_mes(
                                '🤓Укажите в столбик аккаунты и через двоеточие новое время ежедневной проверки(формат: чч.мм):\n\nлогин1:чч.мм\nлогин2:чч.мм')
                            admin_ids[id] = 14
                    elif admin_ids[id] == 14:
                        for time in mes.split('\n'):
                            try:
                                new_time = time.split(':')
                                if len(new_time[1]) == 5:
                                    acc_set_db.update_with_label('cycle_time', 'login', new_time[1],
                                                                 new_time[0])
                                else:
                                    base_mes(
                                        f'⚠В строке {time} были указаны некорректные значения!')
                                    continue
                            except IndexError:
                                base_mes(
                                    f'⚠В строке {time} указано только одно значение. Проверьте, чтобы у Вас было написано два значения через двоеточие!')
                                continue
                            except Exception as ex:
                                logging.exception(ex)
                        base_mes('Время ежедневной проверки успешно отредактировано!')
                        admin_ids[id] = 0
                    else:
                        base_mes('Ничего не понял, но очень интересно🤖')
    except Exception as ex:
        logging.exception(ex)


def get_code_challenge(login, type_code):
    send_to_admins(f"⚠ Пришлите код подтверждения (6 цифр) с {type_code} для аккаунта {login}")
    return CodeWaiter.polling(login)


def keyboard(*args):
    keyboard = VkKeyboard(one_time=False)
    x = False
    for keys in args:
        if x:
            keyboard.add_line()
        else:
            x = True

        for key in keys.keys():
            keyboard.add_button(key, color=keys[key])
    keyboard = keyboard.get_keyboard()
    return keyboard


def coder(text):
    shift_text = ''

    for c in text:

        if c not in alphabet_list:
            shift_text += c
            continue

        i = (alphabet_list.index(c) + shift)
        if i >= len(alphabet_list):
            shift_text += alphabet_list[i - len(alphabet_list)]
        else:
            shift_text += alphabet_list[i]

    return shift_text


def decoder(text):
    shift_text = ''

    for c in text:
        if c not in alphabet_list:
            shift_text += c
            continue

        i = (alphabet_list.index(c) - shift)
        shift_text += alphabet_list[i]

    return shift_text


def check_time_anarchist():
    global already_work, already_used

    print("ПРОВЕРКА ВРЕМЕНИ ЗАПУЩЕНА!")

    times = acc_set_db.select_with_label('login, cycle_time', 'active_check', 1)
    threading.Thread(target=edit_already_used).start()
    while True:
        for account in times:
            try:
                login, account_time = account

                hours, minutes = [int(i) for i in account_time.split('.')]
                date_now = datetime.datetime.now()

                date_now = date_now.hour * 60 * 60 + date_now.minute * 60
                date_account = hours * 60 * 60 + minutes * 60
                is_time_run = 0 <= (date_account - date_now) <= 60

                if login not in already_work + already_used and (is_time_run):
                    already_work.append(login)
                    already_used.append(login)
                    threading.Thread(target=launch_parse, args=(login,)).start()
                    send_launch(login)
            except Exception as ex:
                logging.exception(ex)

        sleep(60)
        times = acc_set_db.select_with_label('login, cycle_time', 'active_check', 1)


def edit_already_used():
    global already_used
    while True:
        sleep(86400)
        already_used = []


def launch_parse(login):
    global already_work
    logging.info('Была совершена попытка запустить проверку')

    try:
        make_deletion(login)
    except Exception as ex:
        logging.exception(ex)
    finally:
        try:
            already_work.remove(login)
        except Exception as ex:
            logging.exception(ex)


def make_deletion(login):
    critical_likes, critical_views, critical_days, time_start_check = get_critical_values(login)
    sleep_randomizer = get_sleep_randomizer(login)
    password = get_password(login)
    proxy = get_proxy(login)

    dl = DeletionLogger(login)

    cl = Client()
    cl.challenge_code_handler = challenge_code_handler
    cl.handle_exception = handle_exception
    cl.change_password_handler = change_password_handler
    if proxy:
        cl.set_proxy(proxy)
    cl.login(login, password)
    time.sleep(10)

    print(datetime.datetime.now(), "Авторизировался", login)

    user_id = int(cl.user_id_from_username(login))

    current_count = 0
    end_cursor = None

    while current_count < MAX_PARSE_POST_COUNT:
        print(datetime.datetime.now(), login, 'Получаю посты:', current_count)
        try:
            medias, end_cursor = cl.user_medias_paginated(user_id, OFFSET_PARSE, end_cursor=end_cursor)
            current_count += OFFSET_PARSE

            for media in medias:
                try:
                    params = is_for_delete(media, critical_likes, critical_views, critical_days, time_start_check)
                    if params:
                        cl.media_delete(media.id)
                        dl.add_deletion(media.media_type, *params)
                        update_deletion_static(login, 1)
                        time.sleep(sleep_randomizer())
                except Exception as ex:
                    logging.exception(ex)
        except Exception as ex:
            current_count += OFFSET_PARSE
            logging.exception(ex)


def create_data_file():
    if data_file in os.listdir():
        f = json.loads(open(data_file, 'r', encoding="utf8").read())
        if f.keys() == data_base.keys():
            return
    clear_json()


def clear_json():
    with open(data_file, 'w', encoding="utf8") as file:
        file.write(json.dumps(data_base))


def get_deletion_statistic() -> dict:
    return json.loads(open(data_file, 'r', encoding="utf8").read())['post_deleted_count']


def update_deletion_static(login, value):
    data = get_deletion_statistic()
    data[login] = data.get(login, 0) + value
    update_static_data_by_key('post_deleted_count', data)


def update_static_data_by_key(key, value):
    data = json.loads(open(data_file, 'r', encoding="utf8").read())
    data[key] = value
    with open(data_file, 'w', encoding="utf8") as file:
        file.write(json.dumps(data))


def clear_static_data():
    data = get_deletion_statistic()
    for login, value in data.items():
        update_deletion_static(login, -value)


def create_list_accs(what, all_i_ve_to_do, login='login'):
    inst_accs = acc_set_db.select(f'{login}, {what}')
    list_accs = ''
    for inst_acc in inst_accs:
        list_accs += f'{inst_acc[0]}:{inst_acc[1]}\n'
    if list_accs:
        message(id,
                f'📝Ниже представлен список нынешних значений в формате:\n{"логин" if login == "login" else "имя в Instagram"}:{all_i_ve_to_do}\n\n{list_accs}',
                base_keyboard)
    else:
        base_mes('К сожалению, Вы не добавили ни одного аккаунта, поэтому редакция невозможна')

    return list_accs


def print_full_list_accs():
    inst_accs = acc_set_db.select('*')
    head = '📝Ниже представлен список аккаунтов инстаграм в следующем формате:\n\n'
    list_accs = ''
    for inst_acc in inst_accs:
        list_accs += f'{inst_acc[0]}) Логин: {inst_acc[1]}\nПароль: {decoder(inst_acc[2])}\nИмя в Instagram: {inst_acc[6]}\nКрит. кол-во лайков: {inst_acc[3]}\nКрит. кол-во просмотров: {inst_acc[4]}\nКрит. кол-во дней: {inst_acc[5]}\nНижний порог возраста: {inst_acc[9]}\nВремя ежедневного запуска: {inst_acc[16]}\nЗадержка между постами лежит в диапозоне от {inst_acc[14]} и до {inst_acc[15]}\n\n'
    text = head + list_accs if list_accs else 'К сожалению, Вами не было залито еще ни одного аккаунта'
    message(id, text, base_keyboard)


def get_password(login) -> str:
    return decoder(acc_set_db.select_with_label('password', 'login', login)[0][0])


def get_critical_values(login) -> tuple:
    return acc_set_db.select_with_label('critical_likes, critical_views, critical_days, time_start_check',
                                        'login', login)[0]


def get_sleep_randomizer(login):
    sleep_min, sleep_max = acc_set_db.select_with_label('sleep_check_post_b, sleep_check_post_f', 'login', login)[0]
    return lambda: randint(sleep_min, sleep_max)


def get_proxy(login) -> str or bool:
    if not int(is_communism_db.select_with_label('communism', 'id', 1)[0][0]):
        proxy = list(acc_set_db.select_with_label('proxy_login, proxy_pass, proxy, port', 'login', login)[0])
    else:
        proxy = list(is_communism_db.select('*')[0])[1:-1]

    login, password, ip, port = proxy
    if login and password and ip and port:
        return f'http://{login}:{password}@{ip}:{port}'
    return False


def is_for_delete(media, critical_likes, critical_views, critical_days, time_start_check) -> (str, str) or bool:
    dt = media.taken_at
    diff = datetime.datetime.now(tz=datetime.timezone.utc) - dt

    if media.media_type == 2 and media.view_count <= critical_views and diff.days >= time_start_check:
        return ('просмотры', f'{media.view_count}<={critical_views}')
    if media.media_type != 2 and media.like_count <= critical_likes and diff.days >= time_start_check:
        return ('лайки', f'{media.like_count}<={critical_likes}')
    if diff.days >= critical_days:
        return ('возраст', f'{diff.days}>={critical_days}')

    return False


def handle_exception(client: Client, error):
    def send_error_to_admin(text):
        send_to_admins(f'Аккаунт: {client.username}\n&#9888; {text}')

    if isinstance(error, BadPassword):
        send_error_to_admin("Не удалось авторизоваться: неверный логин или пароль")
    elif isinstance(error, ChallengeRequired):
        json.loads(client.last_json)
        try:
            client.challenge_resolve(client.last_json)
        except ChallengeRequired as e:
            send_error_to_admin("Проверьте аккаунт, возникла ошибка входа из-за капчи")
        except (ChallengeRequired, SelectContactPointRecoveryForm, RecaptchaChallengeForm) as e:
            send_error_to_admin("Проверьте аккаунт, возникла ошибка входа из-за капчи")
    elif isinstance(error, FeedbackRequired):
        message = client.last_json["feedback_message"]
        if "This action was blocked. Please try again later" in message:
            send_error_to_admin(f"Во время работы бота одно из действий было заблокировано. {message}")
        elif "We restrict certain activity to protect our community" in message:
            # 6 hours is not enough
            send_error_to_admin(f"Инстраграм временно ограничил действия на аккаунте. {message}")
        elif "Your account has been temporarily blocked" in message:
            """
            Based on previous use of this feature, your account has been temporarily
            blocked from taking this action.
            This block will expire on 2020-03-27.
            """
            send_error_to_admin(f"Аккаунту заблокировано действие. {message}")
    elif isinstance(error, PleaseWaitFewMinutes):
        pass

    if not isinstance(error, PleaseWaitFewMinutes):
        raise error


def challenge_code_handler(username, choice):
    logging.info(f'ТРЕБУЕТСЯ КОД {username} {choice}')
    if choice == ChallengeChoice.SMS:
        return get_code_challenge(username, 'SMS')
    elif choice == ChallengeChoice.EMAIL:
        return get_code_challenge(username, 'EMAIL')
    return False


def change_password_handler(username):
    def get_new_end(char: str):
        if char.isdigit():
            return str(max(int(char) % 10, 1))
        else:
            return '1'

    def send_password_to_admin():
        send_to_admins(f'Аккаунт: {username}\n&#128737; Пароль заменён: {password}')

    old_password = get_password(username)
    password = old_password + get_new_end(old_password[-1])

    acc_set_db.update_with_label('password', 'login', username, coder(password))
    logging.info(f"НОВЫЙ ПАРОЛЬ {username} {coder(password)}")
    send_password_to_admin()

    return password


def send_launch(login):
    send_to_admins(f'Начал проверку логина: {login}')


def send_to_admins(text):
    for admin_id in admin_ids.keys():
        try:
            message(admin_id, text)
        except:
            pass


def send_message(user_id, text, n=None, a=None):
    vk.method("messages.send",
              {"peer_id": user_id, "message": str(text), "attachment": a, "keyboard": n,
               "random_id": randint(1, 2147483647)})


def message(user_id, text="", n=None, a=None):
    if len(text) < 4000:
        send_message(user_id, text, n, a)
    else:
        for i in range(0, len(text), 3950):
            send_message(user_id, text[i:i + 3950], n, a)


def base_mes(text):
    message(id, text, base_keyboard)


def clear_every_day(time_for_clear):
    while True:
        try:
            if datetime.datetime.now().strftime('%H:%M') == time_for_clear:
                clear_static_data()
                time.sleep(23.5 * 60 * 60)
            time.sleep(58)
        except Exception as ex:
            pass


if __name__ == '__main__':
    create_data_file()
    clear_old_files(max_file_age)
    threading.Thread(target=clear_every_day, args=('00:00',)).start()
    threading.Thread(target=run_bot).start()
    sleep(0.3)
    check_time_anarchist()

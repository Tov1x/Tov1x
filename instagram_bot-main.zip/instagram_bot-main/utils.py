import time
import datetime
import os

from config import deletion_dir, log_file


def get_datetime_string_now():
    return str(datetime.datetime.now()).split('.')[0].replace(':', '.')


def files_from_today():
    today = datetime.datetime.now().date()

    for file in os.listdir(deletion_dir):
        filetime = datetime.datetime.fromtimestamp(
            os.path.getctime(deletion_dir + '/' + file))
        print(filetime)
        if filetime.date() == today:
            print('true')


def clear_old_files(max_day_old):
    paths = [deletion_dir, log_file]

    for path in paths:
        now = time.time()

        for f in os.listdir(path):
            f = os.path.join(path, f)
            if os.stat(f).st_mtime < now - max_day_old * 86400:
                if os.path.isfile(f):
                    os.remove(f)


class CodeWaiter:
    def __init__(self):
        self.WAIT_LOGIN = []
        self.RESULTS = {}

    def polling(self, login):
        self.WAIT_LOGIN.append(login)

        while login not in self.RESULTS:
            time.sleep(3)
        return self.RESULTS[login]

    def next_login(self):
        if self.WAIT_LOGIN:
            return self.WAIT_LOGIN[0]
        return None

    def add_result(self, result):
        login = self.WAIT_LOGIN.pop(0)
        self.RESULTS[login] = result

    def has_logins(self):
        return len(self.WAIT_LOGIN)


class DeletionLogger:
    def __init__(self, login):
        # self.ct = datetime.datetime.now()
        self.file = f'./{deletion_dir}/{get_datetime_string_now()} - {login}.txt'
        self.login = login
        self.current_text = ''

    def add_deletion(self, media_type, metric, values):
        if media_type == 2:
            media_type = 'видео'
        elif media_type == 1:
            media_type = 'фото'
        elif media_type == 8:
            media_type = 'альбом'
        self.current_text += f"{get_datetime_string_now()}    " \
                             f"{media_type.ljust(10, ' ')}{metric.ljust(10, ' ')}{values.ljust(15, ' ')}\n"
        with open(self.file, mode='w', encoding='utf-8') as f:
            f.write(self.current_text)

from threading import Lock
from time import sleep

import sqlite3
import os

class DB():

    def __init__(self, path, name_table, next_column=''):
        self.lock = Lock()
        self.lock.acquire(True)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        db_path = os.path.join(base_dir, path)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.commit()
        self.lock.release()
        sleep(0.2)
        self.name_table = name_table
        if len(next_column)>2:
            self.create_table(name_table, next_column)

    def create_table(self, name_table, next_column):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        self.conn.execute(f"""CREATE TABLE if not exists {name_table}
                                                           ({next_column}
                                                            );
                                                                   """)
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def add(self, what, *value):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        value_questions = ','.join(['?' for i in range(len(value))])
        cursor.execute(f'insert into {self.name_table}({what}) values({value_questions})', (value), )
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def select_with_label(self, what, label_name, label_val):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'SELECT {what} FROM {self.name_table} WHERE {label_name} = ?', [label_val])
        to_return = cursor.fetchall()
        self.lock.release()
        sleep(0.01)
        return to_return

    def select_with_label_more(self, what, label_name, label_val):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'SELECT {what} FROM {self.name_table} WHERE {label_name} > ?', [label_val])
        to_return = cursor.fetchall()
        self.lock.release()
        sleep(0.01)
        return to_return

    def update_with_label(self, what, label_name, value, label_val):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'UPDATE {self.name_table} SET {what}=? WHERE {label_name}=?', [value, label_val])
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def delete_all(self):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'DELETE FROM {self.name_table}')
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def clear_column(self, name_column):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'UPDATE {self.name_table} SET {name_column}=0')
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def select(self, what):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'SELECT {what} FROM {self.name_table}')
        to_return = cursor.fetchall()
        self.lock.release()
        sleep(0.01)
        return to_return

    def deleter(self, label, label_val):
        sleep(0.01)
        cursor = self.conn.cursor()
        sleep(0.01)
        self.create_lock()
        cursor.execute(f'DELETE FROM {self.name_table} WHERE {label}=?', [label_val])
        self.conn.commit()
        self.lock.release()
        sleep(0.01)

    def create_lock(self):
        self.lock = Lock()
        self.lock.acquire(True)